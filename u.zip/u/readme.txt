-Hey, As per requirement I am completed task explaination in step by step

1. Algorithm
	a. Take Url from user in html page index.php
	b. send url to shorter in same page
	c. save in table name 'url_name' befor save check how many url inserted in a day
	d. take count url inserted in day and create number
	e. number like starting 4 digit year
	f. next 2 digit month 
	g. next 2 digit day
	h. followed by today created (shorted url)
	i. number digit first 6 is fix and next to that you can create nth numbers
	j. number convertion into base 64
	k. this will provide to use with base url

2. Install
	a. copy 'u' folder and store in root directory
	b. change name of db connection in u->db->install.php
	c. server name, user, password and databse name
	d. run the forder like localhost/u/
	e. it will instal automatic

3. Codding Standard
	a. Used coding is core php
	b. included php, css boostrap, mysql and html
	c. index page for creating short link
	d. r.php for redirect url
	e. db/connect.php for db connection
	f. db/install.php install project

