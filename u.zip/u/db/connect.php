<?php

include 'install.php';  //install db and table




$conn = new mysqli($servername, $username, $password, $dbname);    // doing connection




?>