<?php
$servername = "localhost";    // server name
$username = "root";          // user name
$password = "";                // password
$dbname = "url";                // dbname

// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Create database
$sql = "CREATE DATABASE url";
if ($conn->query($sql) === TRUE) {
   
} else {
   
}

$conn->close();


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to create table
$sql = "CREATE TABLE `short` (
  `id` int(255) NOT NULL,
  `url_name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `short_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
";

if ($conn->query($sql) === TRUE) {
 
} else {
   
}
?>